"use strict";
(() => {
  // src/config.ts
  var LANGUAGE_SPEECH_CODES = {
    English: "en-US",
    Khmer: "km-KH",
    Japanese: "ja-JP",
    Chinese: "zh-CN",
    Korean: "ko-KR",
    Vietnamese: "vi-VN",
    French: "fr-FR",
    Spanish: "es-ES",
    German: "de-DE",
    Portuguese: "pt-BR",
    Russian: "ru-RU",
    Arabic: "ar-SA",
    Hindi: "hi-IN",
    Indonesian: "id-ID"
  };
  var DEFAULT_TARGET_LANGUAGE = "Khmer";
  var STORAGE_KEY_TARGET_LANGUAGE = "fluentTargetLanguage";
  var MAX_LOOKUP_TEXT_LENGTH = 500;

  // src/content.ts
  window.addEventListener("error", (e) => {
    if (e.message?.includes("Extension context invalidated")) e.preventDefault();
  });
  function extensionContextGone() {
    try {
      return !chrome.runtime?.id;
    } catch {
      return true;
    }
  }
  var shadowHost = null;
  var shadowRoot = null;
  function ensureShadowRoot() {
    if (shadowRoot) return shadowRoot;
    shadowHost = document.createElement("div");
    shadowHost.id = "fluent-extension-root";
    (document.fullscreenElement ?? document.body).appendChild(shadowHost);
    shadowRoot = shadowHost.attachShadow({ mode: "open" });
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("popover.css");
    shadowRoot.appendChild(link);
    return shadowRoot;
  }
  document.addEventListener("fullscreenchange", () => {
    if (extensionContextGone()) return;
    const container = document.fullscreenElement ?? document.body;
    if (shadowHost) container.appendChild(shadowHost);
    if (captionHost) container.appendChild(captionHost);
  });
  function clearShadowChildren() {
    const root = ensureShadowRoot();
    while (root.childNodes.length > 1) root.removeChild(root.lastChild);
  }
  function removeAll() {
    clearShadowChildren();
  }
  function clampToViewport(top, left, width, height) {
    const margin = 8;
    const maxLeft = window.innerWidth - width - margin;
    const maxTop = window.innerHeight - height - margin;
    return {
      top: Math.max(margin, Math.min(top, maxTop)),
      left: Math.max(margin, Math.min(left, maxLeft))
    };
  }
  function getSelectionRect() {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return null;
    const rect = selection.getRangeAt(0).getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return null;
    return rect;
  }
  function showTrigger(rect, text) {
    removeAll();
    const root = ensureShadowRoot();
    const btn = document.createElement("button");
    btn.className = "fluent-trigger";
    btn.textContent = "\u{1F310} Translate";
    const { top, left } = clampToViewport(rect.bottom + 8, rect.left, 110, 32);
    btn.style.top = `${top}px`;
    btn.style.left = `${left}px`;
    btn.addEventListener("mousedown", (e) => e.preventDefault());
    btn.addEventListener("click", () => {
      void runLookup(text, rect);
    });
    root.appendChild(btn);
  }
  async function getTargetLanguage() {
    const stored = await chrome.storage.sync.get(STORAGE_KEY_TARGET_LANGUAGE);
    return stored[STORAGE_KEY_TARGET_LANGUAGE] ?? DEFAULT_TARGET_LANGUAGE;
  }
  function showPopoverLoading(rect) {
    removeAll();
    const root = ensureShadowRoot();
    const el = document.createElement("div");
    el.className = "fluent-popover";
    const { top, left } = clampToViewport(rect.bottom + 8, rect.left, 300, 90);
    el.style.top = `${top}px`;
    el.style.left = `${left}px`;
    el.innerHTML = `<p class="fluent-popover__status">Translating\u2026</p>`;
    root.appendChild(el);
  }
  async function renderResult(text, rect, outcome, targetLanguage) {
    removeAll();
    const root = ensureShadowRoot();
    const el = document.createElement("div");
    el.className = "fluent-popover";
    if (!outcome.ok) {
      el.innerHTML = `
      <div class="fluent-popover__header">
        <span class="fluent-popover__brand">\u{1F310} Fluent</span>
        <button class="fluent-popover__close" aria-label="Close">\xD7</button>
      </div>
      <p class="fluent-popover__error">${escapeHtml(outcome.error)}</p>
    `;
    } else {
      const { result } = outcome;
      const speechCode = LANGUAGE_SPEECH_CODES[targetLanguage] ?? "en-US";
      el.innerHTML = `
      <div class="fluent-popover__header">
        <span class="fluent-popover__brand">\u{1F310} Fluent</span>
        <span class="fluent-popover__lang">AUTO \u2192 ${escapeHtml(targetLanguage).toUpperCase()}</span>
        <button class="fluent-popover__close" aria-label="Close">\xD7</button>
      </div>
      <p class="fluent-popover__source">${escapeHtml(text)}</p>
      <p class="fluent-popover__translated">"${escapeHtml(result.translatedText)}"</p>
      ${result.phonetic ? `<p class="fluent-popover__phonetic">${escapeHtml(result.phonetic)}</p>` : ""}
      ${result.examples.length ? `<ul class="fluent-popover__examples">${result.examples.map((ex) => `<li>${escapeHtml(ex)}</li>`).join("")}</ul>` : ""}
      <div class="fluent-popover__actions">
        <button data-action="copy">\u{1F4CB} Copy</button>
        <button data-action="listen">\u{1F50A} Listen</button>
      </div>
    `;
      el.querySelector('[data-action="copy"]')?.addEventListener("click", () => {
        void navigator.clipboard.writeText(result.translatedText);
      });
      el.querySelector('[data-action="listen"]')?.addEventListener("click", () => {
        const utterance = new SpeechSynthesisUtterance(result.translatedText);
        utterance.lang = speechCode;
        speechSynthesis.speak(utterance);
      });
    }
    el.querySelector(".fluent-popover__close")?.addEventListener("click", removeAll);
    const { top, left } = clampToViewport(rect.bottom + 8, rect.left, 300, 260);
    el.style.top = `${top}px`;
    el.style.left = `${left}px`;
    root.appendChild(el);
  }
  function escapeHtml(s) {
    const div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }
  var captionHost = null;
  var captionRoot = null;
  function ensureCaptionRoot() {
    if (captionRoot) return captionRoot;
    captionHost = document.createElement("div");
    captionHost.id = "fluent-caption-root";
    (document.fullscreenElement ?? document.body).appendChild(captionHost);
    captionRoot = captionHost.attachShadow({ mode: "open" });
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("popover.css");
    captionRoot.appendChild(link);
    return captionRoot;
  }
  function makeDraggable(bar, handle) {
    let dragging = false;
    let grabX = 0;
    let grabY = 0;
    handle.addEventListener("mousedown", (e) => {
      if (e.target.closest(".fluent-caption-bar__stop")) return;
      dragging = true;
      const rect = bar.getBoundingClientRect();
      grabX = e.clientX - rect.left;
      grabY = e.clientY - rect.top;
      bar.style.left = `${rect.left}px`;
      bar.style.top = `${rect.top}px`;
      bar.style.bottom = "auto";
      bar.style.transform = "none";
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const maxLeft = window.innerWidth - bar.offsetWidth - 8;
      const maxTop = window.innerHeight - bar.offsetHeight - 8;
      bar.style.left = `${Math.min(Math.max(8, e.clientX - grabX), Math.max(8, maxLeft))}px`;
      bar.style.top = `${Math.min(Math.max(8, e.clientY - grabY), Math.max(8, maxTop))}px`;
    });
    document.addEventListener("mouseup", () => {
      dragging = false;
    });
  }
  function showCaptionBar() {
    const root = ensureCaptionRoot();
    if (root.querySelector(".fluent-caption-bar")) return;
    const bar = document.createElement("div");
    bar.className = "fluent-caption-bar";
    bar.innerHTML = `
    <div class="fluent-caption-bar__header">
      <span class="fluent-popover__brand">\u{1F310} Fluent \u2014 Live</span>
      <button class="fluent-caption-bar__stop">Stop</button>
    </div>
    <p class="fluent-caption-bar__source">Listening\u2026</p>
    <p class="fluent-caption-bar__translated"></p>
  `;
    bar.querySelector(".fluent-caption-bar__stop")?.addEventListener("click", () => {
      void chrome.runtime.sendMessage({ type: "FLUENT_STOP_TAB_CAPTURE" });
      hideCaptionBar();
    });
    const header = bar.querySelector(".fluent-caption-bar__header");
    if (header) makeDraggable(bar, header);
    root.appendChild(bar);
  }
  function updateCaptionBar(transcript, translatedText) {
    showCaptionBar();
    const bar = ensureCaptionRoot().querySelector(".fluent-caption-bar");
    if (!bar) return;
    const source = bar.querySelector(".fluent-caption-bar__source");
    const translated = bar.querySelector(".fluent-caption-bar__translated");
    if (source) source.textContent = transcript;
    if (translated) translated.textContent = translatedText;
  }
  function hideCaptionBar() {
    captionRoot?.querySelector(".fluent-caption-bar")?.remove();
  }
  async function runLookup(text, rect) {
    showPopoverLoading(rect);
    const targetLanguage = await getTargetLanguage();
    if (text.length > MAX_LOOKUP_TEXT_LENGTH) {
      await renderResult(
        text,
        rect,
        { ok: false, error: `That's too long to translate at once \u2014 try selecting under ${MAX_LOOKUP_TEXT_LENGTH} characters.` },
        targetLanguage
      );
      return;
    }
    const outcome = await chrome.runtime.sendMessage({ type: "FLUENT_LOOKUP_REQUEST", text });
    await renderResult(text, rect, outcome, targetLanguage);
  }
  document.addEventListener("mouseup", (e) => {
    if (extensionContextGone()) return;
    if (shadowHost && e.composedPath().includes(shadowHost)) return;
    const rect = getSelectionRect();
    if (rect) showTrigger(rect, window.getSelection().toString());
    else removeAll();
  });
  document.addEventListener("mousedown", (e) => {
    if (extensionContextGone()) return;
    if (shadowHost && e.composedPath().includes(shadowHost)) return;
    removeAll();
  });
  document.addEventListener("keydown", (e) => {
    if (extensionContextGone()) return;
    if (e.key === "Escape") removeAll();
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "FLUENT_SHOW_RESULT") return;
    const rect = getSelectionRect();
    if (!rect) return;
    void getTargetLanguage().then((targetLanguage) => {
      void renderResult(message.text, rect, message.outcome, targetLanguage);
    });
  });
  var NO_SIGNAL_TIMEOUT_MS = 12e3;
  var noSignalTimer = null;
  var sawAnySegment = false;
  function clearNoSignalTimer() {
    if (noSignalTimer !== null) {
      clearTimeout(noSignalTimer);
      noSignalTimer = null;
    }
  }
  function armNoSignalTimer() {
    clearNoSignalTimer();
    sawAnySegment = false;
    noSignalTimer = setTimeout(() => {
      const bar = captionRoot?.querySelector(".fluent-caption-bar");
      const translated = bar?.querySelector(".fluent-caption-bar__translated");
      if (!translated || translated.textContent) return;
      translated.textContent = sawAnySegment ? `Hearing audio, but not recognizing clear speech in it yet \u2014 check the "Speaking" language in the popup matches the video, and that it's not just music/background noise.` : "Not picking up any audio from this tab yet \u2014 make sure the video is actually playing (not paused/muted), then reload this page and hit Start again from the toolbar icon.";
    }, NO_SIGNAL_TIMEOUT_MS);
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "FLUENT_TAB_CAPTURE_STARTED") {
      showCaptionBar();
      armNoSignalTimer();
    } else if (message?.type === "FLUENT_TAB_SEGMENT_PROCESSED") {
      sawAnySegment = true;
    } else if (message?.type === "FLUENT_TAB_CAPTION") {
      clearNoSignalTimer();
      updateCaptionBar(message.transcript, message.translatedText);
    } else if (message?.type === "FLUENT_TAB_CAPTURE_STOPPED") {
      clearNoSignalTimer();
      hideCaptionBar();
    } else if (message?.type === "FLUENT_TAB_CAPTURE_ERROR") {
      clearNoSignalTimer();
      showCaptionBar();
      const bar = ensureCaptionRoot().querySelector(".fluent-caption-bar");
      const translated = bar?.querySelector(".fluent-caption-bar__translated");
      if (translated) translated.textContent = "Couldn't start \u2014 try again from the toolbar icon.";
    }
  });
})();
//# sourceMappingURL=content.js.map
