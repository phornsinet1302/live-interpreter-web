"use strict";
(() => {
  // src/config.ts
  var API_URL = "http://localhost:4000/api/v1";
  var DEFAULT_TARGET_LANGUAGE = "Khmer";
  var STORAGE_KEY_TARGET_LANGUAGE = "fluentTargetLanguage";
  var MAX_LOOKUP_TEXT_LENGTH = 500;

  // src/background.ts
  var CONTEXT_MENU_ID = "fluent-translate-selection";
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: CONTEXT_MENU_ID,
      title: 'Translate "%s" with Fluent',
      contexts: ["selection"]
    });
  });
  async function getTargetLanguage() {
    const stored = await chrome.storage.sync.get(STORAGE_KEY_TARGET_LANGUAGE);
    return stored[STORAGE_KEY_TARGET_LANGUAGE] ?? DEFAULT_TARGET_LANGUAGE;
  }
  async function doLookup(text) {
    if (text.length > MAX_LOOKUP_TEXT_LENGTH) {
      return {
        ok: false,
        error: `That's too long to translate at once (${text.length} characters) \u2014 try a passage under ${MAX_LOOKUP_TEXT_LENGTH}.`
      };
    }
    try {
      const targetLanguage = await getTargetLanguage();
      const res = await fetch(`${API_URL}/translate/lookup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, sourceLanguage: "auto", targetLanguage })
      });
      if (!res.ok) {
        return { ok: false, error: `Translation failed (${res.status})` };
      }
      const result = await res.json();
      return { ok: true, result };
    } catch {
      return { ok: false, error: "Couldn't reach Fluent \u2014 check your connection." };
    }
  }
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId !== CONTEXT_MENU_ID || !info.selectionText || !tab?.id) return;
    const outcome = await doLookup(info.selectionText);
    chrome.tabs.sendMessage(tab.id, { type: "FLUENT_SHOW_RESULT", text: info.selectionText, outcome });
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "FLUENT_LOOKUP_REQUEST") return void 0;
    doLookup(message.text).then(sendResponse);
    return true;
  });
  var OFFSCREEN_DOCUMENT_PATH = "offscreen.html";
  var activeCaptureTabId = null;
  var activeSourceLanguage = DEFAULT_TARGET_LANGUAGE;
  var activeTargetLanguage = DEFAULT_TARGET_LANGUAGE;
  async function ensureOffscreenDocument() {
    const has = await chrome.offscreen.hasDocument();
    if (has) return;
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_DOCUMENT_PATH,
      reasons: [chrome.offscreen.Reason.USER_MEDIA],
      justification: "Captures the active tab's audio to transcribe/translate it live."
    });
  }
  async function closeOffscreenDocumentIfOpen() {
    if (await chrome.offscreen.hasDocument()) {
      await chrome.offscreen.closeDocument();
    }
  }
  async function stopTabCapture() {
    const tabId = activeCaptureTabId;
    activeCaptureTabId = null;
    if (await chrome.offscreen.hasDocument()) {
      chrome.runtime.sendMessage({ type: "FLUENT_OFFSCREEN_STOP" });
    }
    await closeOffscreenDocumentIfOpen();
    if (tabId !== null) {
      chrome.tabs.sendMessage(tabId, { type: "FLUENT_TAB_CAPTURE_STOPPED" }).catch(() => {
      });
    }
  }
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (tabId === activeCaptureTabId) void stopTabCapture();
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (tabId === activeCaptureTabId && changeInfo.status === "loading" && changeInfo.url) {
      void stopTabCapture();
    }
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "FLUENT_ENSURE_OFFSCREEN") {
      void ensureOffscreenDocument().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message?.type === "FLUENT_START_TAB_CAPTURE") {
      const { streamId, tabId, sourceLanguage, targetLanguage } = message;
      void (async () => {
        activeCaptureTabId = tabId;
        activeSourceLanguage = sourceLanguage;
        activeTargetLanguage = targetLanguage;
        await ensureOffscreenDocument();
        chrome.runtime.sendMessage({ type: "FLUENT_OFFSCREEN_START", streamId, tabId });
        chrome.tabs.sendMessage(tabId, { type: "FLUENT_TAB_CAPTURE_STARTED" }).catch(() => {
        });
        sendResponse({ ok: true });
      })();
      return true;
    }
    if (message?.type === "FLUENT_OFFSCREEN_ERROR") {
      const { tabId, error } = message;
      console.error("Fluent: offscreen capture failed", error);
      chrome.tabs.sendMessage(tabId, { type: "FLUENT_TAB_CAPTURE_ERROR", error }).catch(() => {
      });
      void stopTabCapture();
      return void 0;
    }
    if (message?.type === "FLUENT_STOP_TAB_CAPTURE") {
      void stopTabCapture().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message?.type === "FLUENT_GET_TAB_CAPTURE_STATUS") {
      const { tabId } = message;
      sendResponse({ active: tabId === activeCaptureTabId });
      return void 0;
    }
    if (message?.type === "FLUENT_TAB_SEGMENT_READY") {
      const { tabId, audioBase64, mimeType } = message;
      if (tabId !== activeCaptureTabId) return void 0;
      void (async () => {
        try {
          const res = await fetch(`${API_URL}/transcribe`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              audio: audioBase64,
              mimeType,
              sourceLanguage: activeSourceLanguage,
              targetLanguage: activeTargetLanguage
            })
          });
          if (!res.ok) {
            console.error("Fluent: /transcribe segment failed", res.status, await res.text().catch(() => ""));
            chrome.tabs.sendMessage(tabId, { type: "FLUENT_TAB_SEGMENT_PROCESSED", hadTranscript: false }).catch(() => {
            });
            return;
          }
          const result = await res.json();
          chrome.tabs.sendMessage(tabId, { type: "FLUENT_TAB_SEGMENT_PROCESSED", hadTranscript: !!result.transcript }).catch(() => {
          });
          if (!result.transcript) return;
          chrome.tabs.sendMessage(tabId, {
            type: "FLUENT_TAB_CAPTION",
            transcript: result.transcript,
            translatedText: result.translatedText
          }).catch(() => {
          });
        } catch (error) {
          console.error("Fluent: segment processing failed", error);
        }
      })();
      return void 0;
    }
    return void 0;
  });
})();
//# sourceMappingURL=background.js.map
