"use strict";
(() => {
  // src/config.ts
  var WEB_APP_URL = "http://localhost:5173";
  var LANGUAGES = [
    "English",
    "Khmer",
    "Japanese",
    "Chinese",
    "Korean",
    "Vietnamese",
    "French",
    "Spanish",
    "German",
    "Portuguese",
    "Russian",
    "Arabic",
    "Hindi",
    "Indonesian"
  ];
  var DEFAULT_TARGET_LANGUAGE = "Khmer";
  var STORAGE_KEY_TARGET_LANGUAGE = "fluentTargetLanguage";
  var MAX_LOOKUP_TEXT_LENGTH = 500;
  var DEFAULT_SOURCE_LANGUAGE = "English";
  var STORAGE_KEY_SOURCE_LANGUAGE = "fluentSourceLanguage";

  // src/popup.ts
  var select = document.getElementById("target-lang");
  var sourceSelect = document.getElementById("source-lang");
  var openApp = document.getElementById("open-app");
  var liveToggle = document.getElementById("live-toggle");
  var liveStatus = document.getElementById("live-status");
  openApp.href = WEB_APP_URL;
  function populate(el) {
    for (const lang of LANGUAGES) {
      const option = document.createElement("option");
      option.value = lang;
      option.textContent = lang;
      el.appendChild(option);
    }
  }
  populate(select);
  populate(sourceSelect);
  chrome.storage.sync.get([STORAGE_KEY_TARGET_LANGUAGE, STORAGE_KEY_SOURCE_LANGUAGE]).then((stored) => {
    select.value = stored[STORAGE_KEY_TARGET_LANGUAGE] ?? DEFAULT_TARGET_LANGUAGE;
    sourceSelect.value = stored[STORAGE_KEY_SOURCE_LANGUAGE] ?? DEFAULT_SOURCE_LANGUAGE;
  });
  select.addEventListener("change", () => {
    void chrome.storage.sync.set({ [STORAGE_KEY_TARGET_LANGUAGE]: select.value });
  });
  sourceSelect.addEventListener("change", () => {
    void chrome.storage.sync.set({ [STORAGE_KEY_SOURCE_LANGUAGE]: sourceSelect.value });
  });
  async function getActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  }
  function setToggleState(active) {
    liveToggle.dataset.active = String(active);
    liveToggle.textContent = active ? "Stop live interpreting" : "Start live interpreting this tab";
    liveStatus.textContent = active ? "Listening to this tab's audio\u2026" : "";
  }
  void (async () => {
    const tab = await getActiveTab();
    if (!tab?.id) return;
    const status = await chrome.runtime.sendMessage({ type: "FLUENT_GET_TAB_CAPTURE_STATUS", tabId: tab.id });
    setToggleState(status?.active ?? false);
  })();
  liveToggle.addEventListener("click", () => {
    void (async () => {
      const active = liveToggle.dataset.active === "true";
      if (active) {
        liveToggle.disabled = true;
        await chrome.runtime.sendMessage({ type: "FLUENT_STOP_TAB_CAPTURE" });
        liveToggle.disabled = false;
        setToggleState(false);
        return;
      }
      const tab = await getActiveTab();
      if (!tab?.id) return;
      liveToggle.disabled = true;
      liveStatus.textContent = "Starting\u2026";
      try {
        await chrome.runtime.sendMessage({ type: "FLUENT_ENSURE_OFFSCREEN" });
        const streamId = await new Promise((resolve, reject) => {
          chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id }, (id) => {
            if (chrome.runtime.lastError || !id) reject(chrome.runtime.lastError ?? new Error("No stream id"));
            else resolve(id);
          });
        });
        await chrome.runtime.sendMessage({
          type: "FLUENT_START_TAB_CAPTURE",
          streamId,
          tabId: tab.id,
          sourceLanguage: sourceSelect.value,
          targetLanguage: select.value
        });
        setToggleState(true);
      } catch {
        liveStatus.textContent = "Couldn't start \u2014 try reloading the page and trying again.";
      } finally {
        liveToggle.disabled = false;
      }
    })();
  });
  var clipboardBtn = document.getElementById("clipboard-translate");
  var clipboardStatus = document.getElementById("clipboard-status");
  var clipboardResultEl = document.getElementById("clipboard-result");
  var clipboardSourceEl = document.getElementById("clipboard-source");
  var clipboardTranslatedEl = document.getElementById("clipboard-translated");
  var clipboardPhoneticEl = document.getElementById("clipboard-phonetic");
  var clipboardCopyBtn = document.getElementById("clipboard-copy");
  clipboardBtn.addEventListener("click", () => {
    void (async () => {
      clipboardResultEl.hidden = true;
      clipboardBtn.disabled = true;
      clipboardStatus.textContent = "Reading clipboard\u2026";
      try {
        const text = (await navigator.clipboard.readText()).trim();
        if (!text) {
          clipboardStatus.textContent = "Clipboard is empty \u2014 copy some text first.";
          return;
        }
        if (text.length > MAX_LOOKUP_TEXT_LENGTH) {
          clipboardStatus.textContent = `That's too long to translate at once (${text.length} characters) \u2014 try copying a shorter passage, under ${MAX_LOOKUP_TEXT_LENGTH}.`;
          return;
        }
        clipboardStatus.textContent = "Translating\u2026";
        const outcome = await chrome.runtime.sendMessage({ type: "FLUENT_LOOKUP_REQUEST", text });
        if (!outcome.ok) {
          clipboardStatus.textContent = outcome.error;
          return;
        }
        clipboardStatus.textContent = "";
        clipboardSourceEl.textContent = text;
        clipboardTranslatedEl.textContent = outcome.result.translatedText;
        if (outcome.result.phonetic) {
          clipboardPhoneticEl.textContent = outcome.result.phonetic;
          clipboardPhoneticEl.hidden = false;
        } else {
          clipboardPhoneticEl.hidden = true;
        }
        clipboardCopyBtn.textContent = "Copy translation";
        clipboardResultEl.hidden = false;
      } catch {
        clipboardStatus.textContent = "Couldn't read the clipboard \u2014 allow clipboard access for Fluent and try again.";
      } finally {
        clipboardBtn.disabled = false;
      }
    })();
  });
  clipboardCopyBtn.addEventListener("click", () => {
    void navigator.clipboard.writeText(clipboardTranslatedEl.textContent ?? "").then(() => {
      clipboardCopyBtn.textContent = "Copied!";
      setTimeout(() => {
        clipboardCopyBtn.textContent = "Copy translation";
      }, 1500);
    });
  });
})();
//# sourceMappingURL=popup.js.map
