"use strict";
(() => {
  // src/config.ts
  var VAD_VOLUME_THRESHOLD = 0.012;
  var VAD_SILENCE_DURATION_MS = 500;
  var VAD_MIN_SPEECH_DURATION_MS = 300;
  var VAD_MAX_SEGMENT_DURATION_MS = 15e3;
  var VAD_POLL_INTERVAL_MS = 50;
  var VAD_HIGHPASS_CUTOFF_HZ = 90;
  var VAD_MIME_TYPE_CANDIDATES = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus"];

  // src/offscreen.ts
  var tabStream = null;
  var processedStream = null;
  var audioContext = null;
  var analyser = null;
  var playbackEl = null;
  var mimeType = "";
  var vadIntervalId = null;
  var currentTabId = null;
  var currentSegment = null;
  var segmentStartAt = 0;
  var speechAccumulatedMs = 0;
  var lastAboveThresholdAt = 0;
  function pickMimeType() {
    for (const candidate of VAD_MIME_TYPE_CANDIDATES) {
      if (MediaRecorder.isTypeSupported(candidate)) return candidate;
    }
    return "";
  }
  function resetSegmentTracking() {
    segmentStartAt = Date.now();
    speechAccumulatedMs = 0;
    lastAboveThresholdAt = 0;
  }
  async function blobToBase64(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    const chunkSize = 32768;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  }
  async function sendSegment(blob, blobMimeType) {
    if (currentTabId === null || blob.size === 0) return;
    const audioBase64 = await blobToBase64(blob);
    void chrome.runtime.sendMessage({
      type: "FLUENT_TAB_SEGMENT_READY",
      tabId: currentTabId,
      audioBase64,
      mimeType: blobMimeType
    });
  }
  function startRecorder() {
    if (!processedStream) return;
    const chunks = [];
    const recorder = new MediaRecorder(processedStream, mimeType ? { mimeType } : void 0);
    const segment = { recorder, chunks, hadSpeech: false };
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) chunks.push(event.data);
    };
    recorder.onstop = () => {
      if (!segment.hadSpeech || chunks.length === 0) return;
      void sendSegment(new Blob(chunks, { type: mimeType || "audio/webm" }), mimeType || "audio/webm");
    };
    recorder.start();
    currentSegment = segment;
    resetSegmentTracking();
  }
  function finalizeCurrentSegment() {
    const segment = currentSegment;
    if (!segment) return;
    segment.hadSpeech = speechAccumulatedMs >= VAD_MIN_SPEECH_DURATION_MS;
    if (segment.recorder.state !== "inactive") segment.recorder.stop();
  }
  function cutSegment() {
    finalizeCurrentSegment();
    startRecorder();
  }
  function vadTick() {
    if (!analyser || !audioContext) return;
    if (audioContext.state === "suspended") void audioContext.resume().catch(() => {
    });
    const data = new Uint8Array(analyser.fftSize);
    analyser.getByteTimeDomainData(data);
    let sumSquares = 0;
    for (let i = 0; i < data.length; i++) {
      const centered = (data[i] - 128) / 128;
      sumSquares += centered * centered;
    }
    const rms = Math.sqrt(sumSquares / data.length);
    const now = Date.now();
    if (rms >= VAD_VOLUME_THRESHOLD) {
      speechAccumulatedMs += VAD_POLL_INTERVAL_MS;
      lastAboveThresholdAt = now;
    }
    const silenceAfterSpeech = speechAccumulatedMs >= VAD_MIN_SPEECH_DURATION_MS && lastAboveThresholdAt > 0 && now - lastAboveThresholdAt >= VAD_SILENCE_DURATION_MS;
    const hitSafetyCap = now - segmentStartAt >= VAD_MAX_SEGMENT_DURATION_MS;
    if (silenceAfterSpeech || hitSafetyCap) cutSegment();
  }
  async function start(streamId, tabId) {
    currentTabId = tabId;
    mimeType = pickMimeType();
    const constraints = {
      audio: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId
        }
      }
    };
    try {
      tabStream = await navigator.mediaDevices.getUserMedia(constraints);
    } catch (error) {
      currentTabId = null;
      void chrome.runtime.sendMessage({
        type: "FLUENT_OFFSCREEN_ERROR",
        tabId,
        error: error instanceof Error ? error.message : String(error)
      });
      return;
    }
    audioContext = new AudioContext();
    const source = audioContext.createMediaStreamSource(tabStream);
    const highpass = audioContext.createBiquadFilter();
    highpass.type = "highpass";
    highpass.frequency.value = VAD_HIGHPASS_CUTOFF_HZ;
    source.connect(highpass);
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 1024;
    highpass.connect(analyser);
    const destination = audioContext.createMediaStreamDestination();
    highpass.connect(destination);
    processedStream = destination.stream;
    playbackEl = new Audio();
    playbackEl.srcObject = tabStream;
    void playbackEl.play().catch(() => {
    });
    startRecorder();
    vadIntervalId = setInterval(vadTick, VAD_POLL_INTERVAL_MS);
  }
  function stop() {
    if (vadIntervalId !== null) {
      clearInterval(vadIntervalId);
      vadIntervalId = null;
    }
    finalizeCurrentSegment();
    currentSegment = null;
    tabStream?.getTracks().forEach((track) => track.stop());
    tabStream = null;
    processedStream = null;
    void audioContext?.close().catch(() => {
    });
    audioContext = null;
    analyser = null;
    if (playbackEl) {
      playbackEl.pause();
      playbackEl.srcObject = null;
      playbackEl = null;
    }
    currentTabId = null;
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "FLUENT_OFFSCREEN_START") {
      void start(message.streamId, message.tabId);
    } else if (message?.type === "FLUENT_OFFSCREEN_STOP") {
      stop();
    }
  });
})();
//# sourceMappingURL=offscreen.js.map
